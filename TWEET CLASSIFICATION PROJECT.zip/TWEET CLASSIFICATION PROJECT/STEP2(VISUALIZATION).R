###Visualization and feature engineering
#set working directory
setwd("D:/Data Scientist/PRO/TweetsClassification")
getwd()

#load libraries
require(tm)        
require(data.table)
require(wordcloud)
require(ggplot2)

#loading data 
tweet = fread('TweetsDataSet.csv', stringsAsFactors = F)
#loading tokenization function and dtm
load('preprocessing.dat')

sparse_dtm = removeSparseTerms(dtm, 0.9992)

# finding word frequency for visualization 
word_freq = sort(colSums(data.table(as.matrix(sparse_dtm))), decreasing = T)
word_freq = data.table(Terms = names(word_freq), frequency = word_freq)


# word cloud 
wordcloud(word_freq$Terms, word_freq$frequency,max.words = 300, scale = c(3,0.2),
          random.order = F, colors=brewer.pal(8, "Dark2"))
f= word_freq[frequency>1500]

# Bar graph for  more frequent words s
ggplot(f, aes(x=Terms, y=frequency))+
  geom_bar(stat = 'identity', fill = 'grey')+
  labs(title= 'Bar Chart for High frequent Terms')+theme_bw()
#clearing graphical memory
graphics.off()

#Word clouds for sarcastic and non-sarcastic tweets

sarcasm = tweet[label == 'sarcastic']
nonsarcasm = tweet[label == 'non-sarcastic']

# corpus for both sarcastic and non-sarcastic
sarcasm_corp = tokenization(sarcasm$tweet)
# Wordcloud for Sarcasm tweet
wordcloud(sarcasm_corp, min.freq = 300, max.words = 300,
          random.order = F, scale = c(3 ,0.2),  colors=brewer.pal(6, "Dark2"))

non_sarcasm_corp = tokenization(nonsarcasm$tweet)
# Wordcloud for Non Sarcasm tweet
wordcloud(non_sarcasm_corp, min.freq = 300, max.words = 300,
          random.order = F, scale = c(3 ,0.2),  colors=brewer.pal(6, "Dark2"))


##Creating MainData set
#converting target variable type to factoer type
tweet$label=as.factor(tweet$label)

#remove sparsity and prepare data frame
sparse = removeSparseTerms(dtm, 0.9992)

df = data.frame(as.matrix(sparse))
Data = data.frame(label = tweet$label,df)

# saving numeric maindata for sampling
save(Data, file='Data.dat')

Data_factor = as.data.frame(Data)

#Binning 
Data_factor = data.frame(lapply(Data[,2:ncol(Data)], function(x){ifelse(x==0,0,1)}))

# Converting numericals to factors 
Data_factor = data.frame(lapply(Data_factor, as.factor))

Data_factor = cbind(label=Data$label, Data_factor)

# saving factor data master.factor
save(Data_factor, file = 'Data_factor.dat')



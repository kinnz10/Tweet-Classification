##Random Forest for classification
setwd("D:/Data Scientist/PRO/TWEET CLASSIFICATION PROJECT")
getwd()

#loading required libraries
require(randomForest)
require(caret)
require(inTrees)

#loading Data
load('TrainTest.dat')

fit_classify=randomForest(label ~.,train, importance=TRUE,do.trace=100 )
pred=predict(fit_classify,test[-1])
xtab=table(obsrved=test[,1],predicted=pred)
confusionMatrix(xtab)

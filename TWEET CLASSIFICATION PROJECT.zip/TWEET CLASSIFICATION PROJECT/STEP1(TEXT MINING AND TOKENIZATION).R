##Data mining and preprocessing
#set working directory
setwd("D:/Data Scientist/PRO/TWEET CLASSIFICATION PROJECT")
getwd()

#load libraries
require(tm)        
require(data.table)

#loading data 
tweet <- fread('TweetsDataSet.csv', stringsAsFactors = F)

#understandind the data
dim(tweet)
str(tweet)
summary(tweet)
head(tweet)
tail(tweet)

#pre processing data
tokenization <-function(corp)
{
  a = c(stopwords("english"),stopwords("SMART"),stopwords("Catalan"))
  
  Space = function(corp){
    corp= gsub("'", ' ', corp)
    corp= gsub('"', ' ', corp)
    
    return(corp)
  }
  
  corp = Corpus(VectorSource(corp))
  corp = tm_map(corp, tolower)
  corp = tm_map(corp, removeNumbers)
  corp = tm_map(corp, removeWords, a)
  corp = tm_map(corp, removePunctuation)
  corp = tm_map(corp, stemDocument)
  corp = tm_map(corp, stripWhitespace)
  
  return(corp)
}

corpus = tokenization(tweet$tweet)
dtm = DocumentTermMatrix(corpus, control = list(weighting = weightTf))
sparse_dtm = removeSparseTerms(dtm, 0.9992)
tweets_df = data.frame(as.matrix(sparse_dtm))

# saving tokenization function and DTM for further operation
save(tokenization, dtm, file = 'preprocessing.dat')


setwd("D:/Data Scientist/PRO/TweetsClassification")
getwd()

require(tm)        
require(data.table)

tweet <- fread('TweetsDataSet.csv', stringsAsFactors = F)
dim(tweet)
str(tweet)
summary(tweet)

head(tweet)
tail(tweet)

vec2clean.corp <- function(x,y=NULL){
  
  # As there are many languages used in the data, we consider stopwords of all the languages
  a = c(stopwords("danish"),stopwords("dutch"),stopwords("english"),
        stopwords("finnish"),stopwords("french"), stopwords('SMART'),
        stopwords("german"),stopwords("hungarian"),stopwords("italian"),
        stopwords("norwegian"),stopwords("portuguese"),stopwords("russian"),
        stopwords("spanish"),stopwords("swedish"))
  
  # Function to replace ' and " to spaces before removing punctuation to avoid different words from binding 
  AposToSpace = function(x){
    x= gsub("'", ' ', x)
    x= gsub('"', ' ', x)
    x =gsub('break','broke',x) # break may interrupt control flow in few functions
    return(x)
  }
  x = Corpus(VectorSource(x))
  print(x$content[[y]])
  x = tm_map(x, tolower)
  print(x$content[[y]])
  x = tm_map(x, removeNumbers)
  print(x$content[[y]])
  x = tm_map(x, removeWords, a)
  print(x$content[[y]])
  x = tm_map(x, AposToSpace)
  print(x$content[[y]])
  x = tm_map(x, removePunctuation)
  print(x$content[[y]])
  x = tm_map(x, stemDocument)
  print(x$content[[y]])
  x = tm_map(x, stripWhitespace)
  print(x$content[[y]])
  
  return(x)
  
}
corp <- vec2clean.corp(tweet$tweet,37)
dtm <- DocumentTermMatrix(corp, control = list(weighting = weightTf))
sparse.dtm <- removeSparseTerms(dtm, 0.999 )
tweets.df <- data.frame(as.matrix(sparse.dtm))
save(vec2clean.corp, dtm, file = 'step1_DS.dat')

###########word cloud
require(data.table)
require(tm)
require(wordcloud)
require(ggplot2)

tweet <- fread('TweetsDataSet.csv')
load('step1_DS.dat')


## creating wordcloud for entire data set

sparse.dtm <- removeSparseTerms(dtm, 0.999 )
sparse.dtm

# creating word frequency data frame
word.freq <- sort(colSums(data.table(as.matrix(sparse.dtm))), decreasing = T)
word.freq <- data.table(Terms = names(word.freq), frequency = word.freq)

# creating word cloud for top 200 words in frequency
wordcloud(word.freq$Terms, word.freq$frequency,max.words = 150, scale = c(4,0.75),
          random.order = F, colors=brewer.pal(8, "Dark2"))
a <- word.freq[frequency>2000]

# Bar graph for words that are more frequent appearing more than 2000 times
ggplot(a, aes(Terms, frequency))+
  geom_bar(stat = 'identity', colour = '#041838', fill = '#0b439e')+
  labs(title= 'Alphabetical ordered High frequent Terms')
#clearing graphical memory
dev.off()

## Seperate Word clouds for sarcastic and non-sarcastic tweets
# subsetting sarcasm and non sarcasm tweets 
sarcasm     <- tweet[label == 'sarcastic']
sarcasm.not <- tweet[label == 'non-sarcastic']

# corpus for both sarcastic and non-sarcastic

corp.sarcasm = vec2clean.corp(sarcasm$tweet, 5)
# Wordcloud for Sarcasm subset
wordcloud(corp.sarcasm, min.freq = 300, max.words = 300,
          random.order = F, scale = c(5 ,0.75),  colors=brewer.pal(8, "Dark2"))

corp.sarcasm.not = vec2clean.corp(sarcasm.not$tweet, 5)
# Wordcloud for Non Sarcasm subset
wordcloud(corp.sarcasm.not, min.freq = 200, max.words = 300,
          random.order = F, scale = c(5 ,0.75),  colors=brewer.pal(8, "Dark2"))

# DTM for sarcasm and non sarcasm corpora
dtm.sar <- DocumentTermMatrix(corp.sarcasm)
dtm.non <- DocumentTermMatrix(corp.sarcasm.not)

# Most frequent 30 words in Sarcasm and non-sarcasm DTMs
findFreqTerms(dtm.sar)[seq(30)]
findFreqTerms(dtm.non)[seq(30)]

# Finding out the most common words and frequent words 
# These words should be eliminated from the master DTM
common <- NULL
for(i in findFreqTerms(dtm.non)[seq(100)]){
  for(j in findFreqTerms(dtm.sar)[seq(100)]){
    if(identical(i,j)){
      common = c(common,i)
      print(i)
    }
  }
}
common # common words are passed to feature engineering code
# common is saved for future references
save(common, file = 'step2_DS.dat')

###############3feature engineering
load('step1_DS.dat')
load('step2_DS.dat')

# load the tweet data set
tweet <- fread('TweetsDataSet.csv')
tweet$label <- as.factor(tweet$label)

#remove sparsity and prepare data frame
sparse <- removeSparseTerms(dtm, 0.9992)
sparse

df <- data.frame(as.matrix(sparse))

# Find associations 
unlist(findAssocs(sparse, findFreqTerms(sparse,100),corlimit = 0.5))
# this may not provide all correlated pairs
rm(dtm,sparse) # as it is not necessary

# we go for pearson correlation matrix to get more detailed info
corr <- data.table(cor(df, use = "complete.obs", method= "pearson"))
corr.terms <- NULL
for(i in 1:(nrow(corr)-1)){
  for(j in (i+1):ncol(corr)){
    if((abs(corr[[i,j]])>0.49) ==T){
      corr.terms = c(corr.terms, names(corr)[i])
      print(paste(colnames(corr)[i],',',colnames(corr)[j])) # print rows and column numbers which are correlated
    }
  }
}
# corr.terms consist of correlated terms which are more than 50% with any other variable
# only one term out correlated pair is added while 'for' loop
rm(corr,i,j)
corr.terms

# combining both common and del.words
del.words <- common
del.words <- unique(del.words)

# removing del.words features from master
df[, (del.words) := NULL]
dim(df)

# creating master data set
master <- data.frame(label = tweet$label, df)

# saving numeric data master for sampling
save(master, file='master.numeric.dat')

# We are going to prepare master.factor from master
rm(list = ls())
# loading numeric master 
load('master.numeric.dat')
master.factor <- as.data.frame(master)

#Binning 
master.factor <- data.frame(lapply(master[,2:ncol(master)], function(x){ifelse(x==0,0,1)}))

# Converting numericals to factors 
master.factor <- data.frame(lapply(master.factor, as.factor))
# master.factor has all categorical variables 0 and 1 factors

master.factor <- cbind(label = master$label, master.factor)

# saving factor data master.factor
save(master.factor, file = 'master.factor.dat')


# This code is about Preparing samples of the master data set and 
# splitting training and testing sets

# clean the environment
rm(list = ls())

# loading necessary libraries
require(caTools)

# function to create sample and push the train and test data sets out
# we are considering sample count as 5022(91298*0.055)
# and 0.8 ratio as training and testing ratio

sample2train.test <- function(master.x, seed.x, samp.ratio= 0.055, train.ratio= 0.8){
  set.seed(seed = seed.x)
  samp.split = sample.split(master.x$label, samp.ratio)
  sample = subset(master.x, samp.split == T)
  
  # training and testing 
  spl = sample.split(sample$label, train.ratio)
  train.x = subset(sample, spl == T )
  test.x  = subset(sample, spl == F )
  return(list(train.x, test.x))
}

# choose the data set you like to use and load the data set 

# to load master.numeric
load('master.numeric.dat')

# to load master.factor
load('master.factor.dat')

# pass the desired master data set, seed(to produce random sample), sample ratio and train ratio
# sample ratio and train ratio are defaulted with 0.055(5022 observations) and 0.8 respectively

# For producing Training and Testing sets of master.numeric
Train.Test.list <- sample2train.test(master,123)

train.num <- Train.Test.list[[1]]
test.num  <- Train.Test.list[[2]]

# saving numeric train and test sets
save(train.num, test.num, file = 'TrainTest_num.dat')

# For producing Training and Testing sets of master.factor
Train.Test.list <- sample2train.test(master.factor,123)

train <- Train.Test.list[[1]]
test  <- Train.Test.list[[2]]

# saving factor train and test sets
save(train, test, file = 'TrainTest.dat')

# Please move to Modelling codes 5.Naive Bayes Training.R, 6.Naive Bayes Evaluation.R
#  7.RandomForestTraining.R , 8.RandomForestEvaluation

# We build Naive Bayes model on master.factor and save the model 
# clean the environment
rm(list = ls())

# loading required package
require(e1071)

# loading Train and Test sets 
load('TrainTest.dat')


# Naive Bayes model classic
n.model <- naiveBayes(label~ ., data = train)


# Naive Bayes model with laplace estimator 1
# laplace = 1 ensures a non-zero probability for every feature
n.model.lap <- naiveBayes(label~ ., data = train, laplace = 1)


# save the model for evaluation
save(n.model,n.model.lap, file= "NB_models.dat")

# please go to 6.NaiveBayesEvaluation.R for Evaluation

# clean the environment
rm(list = ls())


# loading required packages
require(e1071)

# loading Train and Test sets
load('TrainTest.dat')

# loading the Naive Bayes models
load('NB_models.dat')

# Predicting the test target class
# for classic Naive Bayes model
n.pred <- predict(n.model, test[,-1], type = 'class')

xtab.n <- table('Actual class' = test[,1], 'Predicted class' = n.pred )
caret::confusionMatrix(xtab.n)

# for robust Naive Bayes model with laplace estimator
n.pred.lap <- predict(n.model.lap, test[,-1], type = 'class')

xtab.lap <- table('Actual class' = test[,1], 'Predicted class' = n.pred.lap )
caret::confusionMatrix(xtab.lap)

# Random forest model building on master.factor and master.numeric
# and saving the model 

# clean the environment
rm(list = ls())

# loading required package
require(h2o) # to implement random forest quick

# Initializing h2o cluster
h2o.init(nthreads = -1)

#check h2o cluster status
h2o.init()

set.seed(123)
# loading Train and Test sets 
load('TrainTest_num.dat')
load('TrainTest.dat')

# loading data to h2o clusters 
h.train.num <- as.h2o(train.num)
h.train     <- as.h2o(train)


# creating predictor and target indices
x <- 2:ncol(train)
y <- 1
# Building random forest model on numeric data 
rf.model.num <- h2o.randomForest(x=x, y=y, training_frame = h.train.num, ntrees = 1000)

# Building random forest model on factor data
rf.model     <- h2o.randomForest(x=x, y=y, training_frame = h.train, ntrees = 1000)

# saving both models for evaluation 
save(rf.model.num, rf.model, file = 'RF_models.dat')

# Please move to 8.RandomForestEvaluation.R

# Random forest model building on master.factor and master.numeric
# and saving the model 

# clean the environment
rm(list = ls())

# loading required package
require(h2o) # to implement random forest quick

# Initializing h2o cluster
h2o.init(nthreads = -1)

#check h2o cluster status
h2o.init()


# loading Train and Test sets 
load('TrainTest_num.dat')
load('TrainTest.dat')

# loading data to h2o clusters 
h.test.num  <- as.h2o(test.num)
h.test      <- as.h2o(test)

# loading RF models
load('RF_models.dat')

# Evaluating random forest models

# Random forest evaluation for Numeric data
pred.num <- as.data.frame(h2o.predict(rf.model.num, h.test.num))
caret::confusionMatrix(table('Actual class' = test$label,'Predicted class' =  pred.num$predict))

# Random forest evaluation for Factor data
pred <- as.data.frame(h2o.predict(rf.model, h.test))
caret::confusionMatrix(table('Actual class' = test$label, 'Predicted class' = pred$predict))

# shuting down h2o cluster
h2o.shutdown(prompt = F)
# Thank you!
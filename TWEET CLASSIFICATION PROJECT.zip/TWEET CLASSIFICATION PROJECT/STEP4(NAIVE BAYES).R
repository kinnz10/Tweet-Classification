##NaiveBayes model for classification
#set working directory
setwd("D:/Data Scientist/PRO/TWEET CLASSIFICATION PROJECT")
getwd()

# loading package
require(e1071)
require(caret)

# loading Train and Test sets 
load('TrainTest.dat')

# Naive Bayes model classic
nbmodel <- naiveBayes(label~ ., data = train)

# Predicting the test target class
# for classic Naive Bayes model
nbpred <- predict(nbmodel, test[,-1], type = 'class')
xtab <- table('Actual class' = test[,1], 'Predicted class' = nbpred )
confusionMatrix(xtab)

## Naive Bayes model with laplace estimator 1
#The naiveBayes function includes the Laplace parameter.
#Whatever positive integer this is set to will be added into for every class.
#The bigger the laplace smoothing value, the more you are making the models the same.
nbmodel1 <- naiveBayes(label~ ., data = train, laplace = 1)

# for robust Naive Bayes model with laplace estimator
nbpred1 <- predict(nbmodel1, test[,-1], type = 'class')

xtab1<- table('Actual class' = test[,1], 'Predicted class' = nbpred1 )
confusionMatrix(xtab1)



# save the model for evaluation
save(nbmodel,nbmodel1, file= "NBmodels.dat")






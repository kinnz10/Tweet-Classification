###Sampling data and split into train and test
#set working directory
setwd("D:/Data Scientist/PRO/TWEET CLASSIFICATION PROJECT")
getwd()

#load libraries
require(caTools)

# function to create sample and push the train and test data sets out
# we are considering sample count as 4565(91298*0.05)
# and 0.75 ratio as training and testing ratio

sampling <- function(data, sampRatio=0.05,splitRatio= 0.75){
  set.seed=123
  split = sample.split(data$label, sampRatio)
  sample = subset(data, split == T)
  
  # training and testing 
  sample1 = sample.split(sample$label, splitRatio)
  train = subset(sample, sample1 == TRUE)
  test  = subset(sample, sample1 == FALSE)
  
  return(list(train, test))
}



# to load Data numeric
load('Data.dat')

# to load Data_factor
load('Data_factor.dat')

# For producing Training and Testing sets of Data
 sample<- sampling(Data)

train_num <- sample[[1]]
test_num  <- sample[[2]]

# saving numeric train and test sets
save(train_num, test_num, file = 'TrainTest_num.dat')

# For producing Training and Testing sets of Data_factor
sample1 <- sampling(Data_factor)

train <- sample1[[1]]
test  <- sample1[[2]]

# saving factor train and test sets
save(train, test, file = 'TrainTest.dat')



